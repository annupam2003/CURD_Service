﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace ApiDemo.Controllers
{
    [Route("/[controller]/[action]")]
    public class HomeController : Controller
    {
        IBlogsRepository xblog;
        public HomeController(IBlogsRepository _blog)
        {
            xblog=_blog;
        }
        [Route("~/")]
        public string Index()
        {
            return "Home.Index";
        }

        [HttpGet]
        [ActionName("Index")]
        public JsonResult AllCase()
        {
            IEnumerable<Blogs> b = xblog.GetBlogs().OrderBy(x=>x.Id);
            return Json(b);
        }
        [HttpGet]
        [ActionName("Index/{Id}")]
        public JsonResult Single(int Id=0)
        {
            Blogs b = xblog.GetBlog(Id);
            return Json(b);
        }

        [HttpPost]
        [ActionName("Post")]
        public JsonResult AddSingle([FromBody] Blogs blog)
        {
            if (blog == null)
                return Json(new Blogs());
            else
                return Json(xblog.SingleAdd(blog));
        }

        [HttpDelete]
        [ActionName("Delete/{Id}")]
        public JsonResult Delete(int Id)
        {
            Blogs b = xblog.Delete(Id);
            return Json(b);
        }

        [HttpPut]
        [ActionName("Put")]
        public JsonResult Update([FromBody] Blogs blog)
        {
            Blogs b = xblog.Update(blog);
            return Json(b);
        }
    }
}