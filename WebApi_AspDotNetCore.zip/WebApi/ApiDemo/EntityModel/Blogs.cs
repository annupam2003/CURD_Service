﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime;
using System.Threading.Tasks;

namespace ApiDemo
{
    public class Blogs
    {
        public int? Id { get; set; }
        public DateTime? DateIs { get; set; }
        public bool? IsActive { get; set; }
        public string Name { get; set; }
        public string title { get; set; }
        public string details { get; set; }

        public Blogs()
        {
            Id = null;
            DateIs = DateTime.Now;
            IsActive = true;
            Name = "";
            title = "";
            details = "";
        }
    }
}
