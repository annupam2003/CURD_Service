﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiDemo
{
    public class BlogSqlServerRepository : IBlogsRepository
    {
        readonly AppDbContext context;
        public BlogSqlServerRepository(AppDbContext context)
        {
            this.context = context;
        }

        Blogs IBlogsRepository.GetBlog(int Id)
        {
            return context.Blogs.Where(x => x.Id == Id).FirstOrDefault();
        }

        IEnumerable<Blogs> IBlogsRepository.GetBlogs()
        {
            var blogs = context.Blogs;
            return blogs;
        }
        public Blogs SingleAdd(Blogs blog)
        {
            context.Blogs.Add(blog);
            context.SaveChanges();
            return blog;
        }

        public Blogs Delete(int Id)
        {
            Blogs b = context.Blogs.Where(x => x.Id == Id).FirstOrDefault();
            if (b != null)
            {
                context.Blogs.Remove(b);
                context.SaveChanges();
            }
            return b;
        }

        public Blogs Update(Blogs blog)
        {
            var b =context.Blogs.Attach(blog);
            b.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            context.SaveChanges();
            return blog;
        }
    }
}
