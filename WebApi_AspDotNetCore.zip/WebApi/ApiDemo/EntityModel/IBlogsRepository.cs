﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiDemo
{
    public interface IBlogsRepository
    {
        IEnumerable<Blogs> GetBlogs();
        Blogs GetBlog(int Id);
        Blogs SingleAdd(Blogs blog);
        Blogs Delete(int Id);
        Blogs Update(Blogs blog);

    }
}
