import { Component, OnInit } from '@angular/core';
import { ConfigService } from 'src/app/config/config.service';
import { IBlogs } from 'src/app/Entity/IBlogs';

@Component({
  selector: 'postblog',
  templateUrl: './postblog.component.html',
  styleUrls: ['./postblog.component.css']
})
export class PostblogComponent implements OnInit {

  bb:IBlogs;

  constructor(private service: ConfigService) { 
    this.bb = new IBlogs();
    //this.bb.id=0;
    //this.bb.dateIs=Date.now;
    this.bb.isActive=true;
    this.bb.name="angular";
    this.bb.title="angular Title";
    this.bb.details="angular details";
  }

  ngOnInit(): void {
    this.postConfig(this.bb);
  }

  postConfig(blog : IBlogs){
    console.log("Post");
    this.service.postConfig(blog).subscribe(x=>{console.log(x)});
  }

}
