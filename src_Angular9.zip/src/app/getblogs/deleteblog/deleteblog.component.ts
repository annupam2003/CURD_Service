import { Component, OnInit } from '@angular/core';
import { ConfigService } from 'src/app/config/config.service';

@Component({
  selector: 'deleteblog',
  templateUrl: './deleteblog.component.html',
  styleUrls: ['./deleteblog.component.css']
})
export class DeleteblogComponent implements OnInit {

  constructor(private service:ConfigService) { }

  ngOnInit(): void {
    this.delete(10);
  }

  delete(Id: any){
    this.service.deleteConfig(Id).subscribe(x=>{ console.log(x)});
  }

}
