import { Component, OnInit } from '@angular/core';
import { IBlogs } from 'src/app/Entity/IBlogs';
import { ConfigService } from 'src/app/config/config.service';

@Component({
  selector: 'getall',
  templateUrl: './getall.component.html',
  styleUrls: ['./getall.component.css']
})
export class GetallComponent implements OnInit {
  
  blogs : IBlogs[];
  
  constructor(private services:ConfigService){  }
  ngOnInit(): void {
    this.getData();
  }

  getData()
  {
    this.services.getConfig().subscribe( x => { this.blogs = x ; console.log(this.blogs); });
  }

}
