import { Component, OnInit } from '@angular/core';
import { ConfigService } from 'src/app/config/config.service';
import { IBlogs } from 'src/app/Entity/IBlogs';

@Component({
  selector: 'updateblog',
  templateUrl: './updateblog.component.html',
  styleUrls: ['./updateblog.component.css']
})
export class UpdateblogComponent implements OnInit {

  blog : IBlogs;
  constructor(private services : ConfigService) { 

    this.blog = new IBlogs();
    this.blog.id=6;
    //this.blog.dateIs=Date.now;
    this.blog.isActive=true;
    this.blog.name="angular5";
    this.blog.title="angular Title5";
    this.blog.details="angular details5";
    
  }

  ngOnInit(): void {
     this.Update();
  }

  Update(){
    this.services.putConfig(this.blog).subscribe(x=>{ console.log(x) });
  }

}
