import { Component, OnInit } from '@angular/core';
import { ConfigService } from './config/config.service';
import { IBlogs } from './Entity/IBlogs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent  {
  title = 'ServiceDemo';
}
