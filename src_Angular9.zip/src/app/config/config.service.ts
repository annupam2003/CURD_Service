import { Injectable } from '@angular/core';
import { HttpClientModule,HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IBlogs } from '../Entity/IBlogs';


@Injectable({
  providedIn: 'root'
})

export class ConfigService {
baseUrl : string="http://localhost:81/WebApiDemo/"; //"http://localhost:5000/"; //

  constructor(private http: HttpClient) { }

  getConfig() : Observable<IBlogs[]>
  {
    return this.http.get<IBlogs[]>(this.baseUrl+"home/index");
  }

  getSingleConfig(Id : number) : Observable<IBlogs>
  {
    return this.http.get<IBlogs>(this.baseUrl+"home/index/"+Id);
  }
  postConfig(b:IBlogs) : Observable<IBlogs>
  {
    return this.http.post<IBlogs>(this.baseUrl+"home/post",b);
  }
  putConfig(b:IBlogs) : Observable<IBlogs>
  {
    return this.http.put<IBlogs>(this.baseUrl+"home/put",b);
  }
  deleteConfig(Id : number) : Observable<IBlogs>
  {
    return this.http.delete<IBlogs>(this.baseUrl+"home/delete/"+Id);
  }
}
