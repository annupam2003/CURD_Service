import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GetallComponent } from './getblogs/getall/getall.component';
import { PostblogComponent } from './getblogs/postblog/postblog.component';
import { UpdateblogComponent } from './getblogs/updateblog/updateblog.component';
import { DeleteblogComponent } from './getblogs/deleteblog/deleteblog.component';



@NgModule({
  declarations: [
    AppComponent,
    GetallComponent,
    PostblogComponent,
    UpdateblogComponent,
    DeleteblogComponent
  ],

  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
