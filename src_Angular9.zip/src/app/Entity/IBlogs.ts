export class IBlogs{
    id : number;
    dateIs : Date;
    isActive : Boolean;
    name: string;
    title : string;
    details :string;
}